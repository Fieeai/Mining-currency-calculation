import requests
url='https://api.pyrin.network/info/blockreward'
max_attempts = 3
attempts = 0
while attempts < max_attempts:
    try:
        r=requests.get(url)
        if r.status_code == 200:
            response=r.json()
            b_rew=response['blockreward']
            print(b_rew)
            break
        else:
            attempts += 1
            continue
    except requests.exceptions.RequestException:
        attempts += 1
        continue
if attempts >= max_attempts:
    print("xxx")