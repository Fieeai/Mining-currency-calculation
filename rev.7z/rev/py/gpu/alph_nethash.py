import requests
import re
url='https://wallet-v20.mainnet.alephium.org/infos/current-hashrate'
max_attempts = 3
attempts = 0
while attempts < max_attempts:
    try:
        r=requests.get(url)
        if r.status_code == 200:
            response=r.json()
            nethash_u=response['hashrate']
            nethash_o=re.search(r'\d+',nethash_u)
            nethash_m=int(nethash_o.group())
            print(nethash_m)
            break
        else:
            attempts += 1
            continue
    except requests.exceptions.RequestException:
        attempts += 1
        continue
if attempts >= max_attempts:
    print("xxx")