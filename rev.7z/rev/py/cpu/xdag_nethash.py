import requests
url='https://explorer.xdag.io/api/status'
max_attempts = 3
attempts = 0
while attempts < max_attempts:
    try:
        r=requests.get(url)
        if r.status_code == 200:
            response=r.json()
            nh_h=response['stats']['hashrate'][1]
            nh_m=nh_h/1000000
            print(round(nh_m,2))
            break
        else:
            attempts += 1
            continue
    except requests.exceptions.RequestException:
        attempts += 1
        continue
if attempts >= max_attempts:
    print("xxx")